FAQ Template
=========
An easy to customize template for the FAQ section of your project, with the questions/answers grouped in categories to ease the navigation.

[Article on CodyHouse](http://codyhouse.co/gem/css-faq-template/)

[Demo](http://codyhouse.co/demo/faq-template/index.html)
 
[Terms](http://codyhouse.co/terms/)
